﻿using System; //Only this line is needed as all else can be called under System

namespace DebugFixMethods
{
    class Program
    {
        static void Main(string[] args)
        {
            (new Program()).Run(); //Needed to be "Run" as method names are case sensitive
        }


        void Run()
        {
            int choice = 0;

            WritePrompt();
            choice = ReadChoice();
            WriteChoice(choice);

        }

        void WritePrompt()
        {
            Console.WriteLine("Thompson");
            Console.WriteLine("Please select a course for which you want to register by typing the number inside []");
            Console.WriteLine("[1]IT 145\n[2]IT 200\n[3]IT 201\n[4]IT 270\n[5]IT 315\n[6]IT 328\n[7]IT 330");
            Console.Write("Enter your choice : ");
        }

        int ReadChoice() //Rewritten to properly convernt input string to int and validate input
        {
            while (true)
            {
                string input = Console.ReadLine(); // Get user input
                int choice;

                // Validate if the input can be parsed to an integer and is within the range 1 to 7
                if (int.TryParse(input, out choice) && choice >= 1 && choice <= 7)
                {
                    return choice; // Return valid input
                }
                else
                {
                    Console.WriteLine("Invalid input. Please enter a number between 1 and 7:"); // Prompt user again for valid input
                }
            }
        }

        void WriteChoice(int choice) //Parameter needs type declaration
        {
            Console.WriteLine("Your choice is {0}", choice);
        }

    }
}
