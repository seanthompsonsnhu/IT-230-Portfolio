﻿using System;

namespace DebugFixIFStmt
{
    class Program
    {
        static void Main(string[] args)
        {
            (new Program()).run();
        }


        void run()
        {
            int firstChoice = 0, secondChoice = 0, thirdChoice = 0;

            System.Console.WriteLine("Thompson");

            firstChoice = 0; secondChoice = 0; thirdChoice = 0;
            WriteCurrentChoices(firstChoice, secondChoice, thirdChoice);

            firstChoice = 2; secondChoice = 0; thirdChoice = 0;
            WriteCurrentChoices(firstChoice, secondChoice, thirdChoice);

            firstChoice = 2; secondChoice = 5; thirdChoice = 0;
            WriteCurrentChoices(firstChoice, secondChoice, thirdChoice);

            firstChoice = 2; secondChoice = 5; thirdChoice = 7;
            WriteCurrentChoices(firstChoice, secondChoice, thirdChoice);
        }


        void WriteCurrentChoices(int firstChoice, int secondChoice, int thirdChoice)
        {
            if (firstChoice == 0) //Should be set to firstChoice
                Console.WriteLine($"Choices are: {firstChoice}, {secondChoice}, {thirdChoice} => There are no choices yet");
            else if (secondChoice == 0) //Needs == for comparative, just one sets the value
                Console.WriteLine($"Choices are: {firstChoice}, {secondChoice}, {thirdChoice} => Currently choices are {firstChoice}");
            else if (thirdChoice == 0) //=== is not a valid operator
                Console.WriteLine($"Choices are: {firstChoice}, {secondChoice}, {thirdChoice} => Currently choices are {firstChoice}, {secondChoice}");
            else if(thirdChoice != 0 )
                Console.WriteLine($"Choices are: {firstChoice}, {secondChoice}, {thirdChoice} => Currently choices are {firstChoice }, {secondChoice}, {thirdChoice}");
        }
    }
}
