﻿using System;

namespace CreateClassesObjs
{
    public class Course
    {
        //Private string field to hold the name of the course
        private string courseName;

        //Method to set the name field to a given string value
        public void setName(string name)
        {
            courseName = name;
        }

        //Method to retrieve the name field
        public string getName()
        { 
            return courseName;
        }

        //Overriding the ToString() method to return the name field
        public override string ToString()
        {
            return courseName;
        }
    }
}
